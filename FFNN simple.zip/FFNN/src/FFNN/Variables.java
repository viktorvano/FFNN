package FFNN;

import java.util.LinkedList;

public class Variables {
    /*
        vector (c++)   <===========> linkedlist(java)
        v.front()      <===========> l.peekFirst()
        v.back()       <===========> l.peekLast()
        v.push_back(x) <===========> l.add(x)
        v.pop_back()   <===========> l.pollLast()
    */
    public static int patternCount =  16;
    public static int inputNodes= 4;
    public static int hiddenNodes = 32;
    public static int outputNodes = 2;
    public static double velocity= 0.1; // overall net learning rate [0.0..1.0]
    public static double momentum = 0.5; // momentum multiplier of last deltaWeight [0.0..n]

    public static final double[][] LearningInputs = { //[PatternCount][InputNodes]
        { 0.0, 0.0, 0.0, 0.0 },
        { 0.0, 0.0, 0.0, 1.0 },
        { 0.0, 0.0, 1.0, 0.0 },
        { 0.0, 0.0, 1.0, 1.0 },
        { 0.0, 1.0, 0.0, 0.0 },
        { 0.0, 1.0, 0.0, 1.0 },
        { 0.0, 1.0, 1.0, 0.0 },
        { 0.0, 1.0, 1.0, 1.0 },
        { 1.0, 0.0, 0.0, 0.0 },
        { 1.0, 0.0, 0.0, 1.0 },
        { 1.0, 0.0, 1.0, 0.0 },
        { 1.0, 0.0, 1.0, 1.0 },
        { 1.0, 1.0, 0.0, 0.0 },
        { 1.0, 1.0, 0.0, 1.0 },
        { 1.0, 1.0, 1.0, 0.0 },
        { 1.0, 1.0, 1.0, 1.0 },
    };

    public static final double[][] LearningOutputs = { //[PatternCount][OutputNodes]
        { 0.0, 1.0 },// LearningOutputs[x][0] represents AND for LearningInputs[x][0,1]
        { 0.0, 0.0 },// LearningOutputs[x][1] represents XNOR for LearningInputs[x][0,1,2,3]
        { 0.0, 0.0 },
        { 0.0, 0.0 },
        { 0.0, 0.0 },
        { 0.0, 0.0 },
        { 0.0, 0.0 },
        { 0.0, 0.0 },
        { 0.0, 0.0 },
        { 0.0, 0.0 },
        { 0.0, 0.0 },
        { 0.0, 0.0 },
        { 1.0, 0.0 },
        { 1.0, 0.0 },
        { 1.0, 0.0 },
        { 1.0, 1.0 },
    };

    public static int trainingLine = 0;// Has to be initialized 0
    public static LinkedList<Double> input, target, result;
    public static int trainingPass = 0;
}
